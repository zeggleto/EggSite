export class Experience {
    public name: string;
    public time: string;
    public title: string;
    public place: string;
}
