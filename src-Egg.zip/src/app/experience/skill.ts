import { Language } from './language';

export class Skill {
    public name: string;
    public languages: Language[];
    public other: string;
}
