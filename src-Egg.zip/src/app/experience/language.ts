export class Language {
    public name: string;
    public level: number;
}
